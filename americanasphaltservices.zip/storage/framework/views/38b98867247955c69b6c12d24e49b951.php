<section id="contact-section" class="mt-0">
    <div class="container">
      <div class="row">
        <div class="col-lg-7">
        <div class="contact-ctn-box">
  <h2><?php echo e($contactInfo->discount); ?></h2>
  <p><?php echo e($contactInfo->text); ?></p>
        </div>
        </div>
        <div class="col-lg-5 align-self-center">
        <div class="call-box">
        <div class="media">
  <img src="<?php echo e(asset('frontend/images/contact-icon.png')); ?>"class="img-fluid mr-3">
  <div class="media-body align-self-center">
    <?php
    // Original phone number (assuming it's stored as a continuous string)
    $originalNumber = $contactInfo->number;
    
    // Format the phone number
    $formattedNumber = substr($originalNumber, 0, 3) . '-' . 
                       substr($originalNumber, 3, 3) . '-' . 
                       substr($originalNumber, 6);
?>

<h5><a href="tel:<?php echo e($originalNumber); ?>"><?php echo e($formattedNumber); ?></a></h5>
  </div>
  </div>
        </div>
        </div>
        </div>
      </div>
    </section>
    
    <section id="client-section">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
        <div id="demo-pranab">
        <div id="owl-client" class="owl-carousel owl-theme">     
         

          <?php $__currentLoopData = $partnerlogos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="item">
          <div class="client-box">
  <img src="<?php echo e(asset('storage/partner_logos/' . $item->image)); ?>"class="img-fluid" alt="...">
          </div>
          </div>
          
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
  
          </div>
          
          </div>
  </div>
  </div>
  </div>
    </section><?php /**PATH D:\xampp\htdocs\americanasphaltservices\resources\views/Frontend/Layout/contactinfo.blade.php ENDPATH**/ ?>