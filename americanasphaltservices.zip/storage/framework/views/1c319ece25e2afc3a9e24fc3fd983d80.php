<?php $__env->startSection("content"); ?>




     <section id="banner-slider" class="banner-slider">
      <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <!--<ol class="carousel-indicators">
          <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
        </ol>-->
        <div class="carousel-inner" role="listbox">
          <!-- Slide One - Set the background image for this slide in the line below -->
          <div class="carousel-item active" style="background-image: url('<?php echo e(asset('frontend/images/banner.jpg')); ?>');">
		  <canvas id="canvas"></canvas>
            <div class="carousel-caption">
			  <h1>American Asphalt Services</h1>
			  <p class="banner-ctn">Our full service concrete and asphalt services include all paving, sealcoating, asphalt repair, pothole repair, striping, and snow removal.</p>
			  <a href="<?php echo e(route('contact_us')); ?>" class="banner-btn">Contact Us Now</a>
            </div>
          </div> 
		  
          <!-- Slide Two - Set the background image for this slide in the line below -->
     <!-- <div class="carousel-item" style="background-image: url('images/banner2.jpg')">
            <div class="carousel-caption">
			
			
            </div>
          </div>  -->

        </div>
     <!-- <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"><img src="<?php echo e(asset('frontend/images/ban-left-btn.png')); ?>"class="img-fluid"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"><img src="<?php echo e(asset('frontend/images/ban-right-btn.png')); ?>"class="img-fluid"></span>
          <span class="sr-only">Next</span>
        </a>-->
      </div>
    </section>
    <!-- Page Content -->
	
<section id="line-section">
<img src="<?php echo e(asset('frontend/images/c-line.png')); ?>"class="img-fluid w-100">
</section>
	
	<section id="welcome-section">
	<div class="container">
	    <div class="row">
		<div class="col-lg-4">
		<img src="<?php echo e(asset('frontend/images/wel-pic1.jpg')); ?>"class="img-fluid w-100 mb-2 wel-img">
        </div>
		<div class="col-lg-2">
		<div class="wel-img-ctn">
		<h5>10 years</h5>
<p>Experiences</p>
</div>
		<img src="<?php echo e(asset('frontend/images/wel-pic2.jpg')); ?>"class="img-fluid w-100 mb-2 wel-img">
        </div>
		
        <div class="col-lg-6 align-self-center">
		<div class="hm-about-ctn-box">
<div class="hm-about-topctn">
		<p class="head-caption">about us</p>
		<h2>Colorado Concrete and Asphalt Services</h2>
		<p>American Asphalt Services, based in Colorado Springs, boasts over 30 years of expertise in the asphalt industry. Our comprehensive range of services covers concrete and paving across the Front Range, encompassing paving, sealcoating, pothole repair, crack fill, parking lot striping, and snow removal. As a bonded and insured company backed by Statefarm Insurance, we are committed to using only the finest quality products and employing highly trained professionals to deliver the best Colorado asphalt services to our clients. Furthermore, we offer FREE estimates and are more than happy to arrange a meeting at your place of business or home to discuss your requirements.</p>
		 </div>
		
		<div class="row justify-content-between my-3">
		<div class="col-lg-6">
		<div class="media">
  <img src="<?php echo e(asset('frontend/images/wel-icon1.png')); ?>"class="mr-3" alt="...">
  <div class="media-body align-self-center">
   <h5>Quality Materials</h5>
  </div>
</div>
		</div>
		
		<div class="col-lg-6">
		<div class="media">
  <img src="<?php echo e(asset('frontend/images/wel-icon2.png')); ?>"class="mr-3" alt="...">
  <div class="media-body align-self-center">
   <h5>Expert<br> Engineer</h5>
  </div>
</div>
		</div>
		
		</div>
<a href="" class="rm-btn">More About Us <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
        </div>
		</div>		
      </div>
	  </div>
	</section>
	
	
	
	<section id="service-section">
	<div class="container-fluid">
	  <div class="row justify-content-center serv-head">
	  <div class="col-lg-10 text-center">
		<h2>What We <span>Do</span></h2>
		<p class="head-txt">Our full service concrete and american asphalt services include all paving, sealcoating.</p>
	  </div>        
</div>
<div class="row">
		<div class="col-lg-12">
		<div id="demo-pranab">
        <div id="owl-services" class="owl-carousel owl-theme">     
          <div class="item">
		  <div class="service-box">
		  <div class="service-box-img">
  <img src="<?php echo e(asset('frontend/images/serv-pic1.jpg')); ?>"class="img-fluid mb-4">
		  </div>
		  <div class="service-box-ctn">
  <h3>Residential</h3>
  <p>Are you a homeowner? American Asphalt Services offers residential asphalt services across the front range.</p>
  <a href="">Read More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
		  </div>
		  </div>
		  </div>
		  <div class="item">
		  <div class="service-box">
		  <div class="service-box-img">
  <img src="<?php echo e(asset('frontend/images/serv-pic2.jpg')); ?>"class="img-fluid mb-4">
		  </div>
		  <div class="service-box-ctn">
  <h3>Commercial</h3>
  <p>Calling all business owners! American Asphalt Services offers commercial asphalt services in Colorado.</p>
  <a href="">Read More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
		  </div>
		  </div>
		  </div>
		  <div class="item">
		  <div class="service-box">
		  <div class="service-box-img">
  <img src="<?php echo e(asset('frontend/images/serv-pic3.jpg')); ?>"class="img-fluid mb-4">
		  </div>
		  <div class="service-box-ctn">
  <h3>Concrete</h3>
  <p>We offer concrete services including curbs, gutters, driveways, walkways, sidewalks, patios, & stained concrete.</p>
  <a href="">Read More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
		  </div>
		  </div>
		  </div>
		  <div class="item">
		  <div class="service-box">
		  <div class="service-box-img">
  <img src="<?php echo e(asset('frontend/images/serv-pic4.jpg')); ?>"class="img-fluid mb-4">
		  </div>
		  <div class="service-box-ctn">
  <h3>Asphalt Paving</h3>
  <p>We are your one-stop shop for any asphalt paving or repair needs. We provide nothing but the best asphalt services in Colorado Springs.</p>
  <a href="">Read More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
		  </div>
		  </div>
		  </div>
		  <div class="item">
		  <div class="service-box">
		  <div class="service-box-img">
  <img src="<?php echo e(asset('frontend/images/serv-pic5.jpg')); ?>"class="img-fluid mb-4">
		  </div>
		  <div class="service-box-ctn">
  <h3>Snow Removal</h3>
  <p>When winter weather strikes in Colorado Springs, reliable snow removal is essential for residential and commercial properties.</p>
  <a href="">Read More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
		  </div>
		  </div>
		  </div>
		  <div class="item">
		  <div class="service-box">
		  <div class="service-box-img">
  <img src="<?php echo e(asset('frontend/images/serv-pic6.jpg')); ?>"class="img-fluid mb-4">
		  </div>
		  <div class="service-box-ctn">
  <h3>Patching & Crack Filling</h3>
  <p>American Asphalt Services is your trusted Colorado asphalt services partner in maintaining the integrity and longevity of your asphalt surfaces. </p>
  <a href="">Read More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
		  </div>
		  </div>
		  </div>
		   
		  </div>
		  
          </div>
</div>
<div class="col-lg-12 service-link">
<p>Want to see our company industrial services...<a href="">View More Services</a></p>
</div>
</div>

</div>
	</section>
	
	<section id="contact-section" class="mt-0">
    <div class="container">
      <div class="row">
        <div class="col-lg-7">
        <div class="contact-ctn-box">
  <h2><?php echo e($contactInfo->discount); ?></h2>
  <p><?php echo e($contactInfo->text); ?></p>
        </div>
        </div>
        <div class="col-lg-5 align-self-center">
        <div class="call-box">
        <div class="media">
  <img src="<?php echo e(asset('frontend/images/contact-icon.png')); ?>"class="img-fluid mr-3">
  <div class="media-body align-self-center">
    <?php
    // Original phone number (assuming it's stored as a continuous string)
    $originalNumber = $contactInfo->number;
    
    // Format the phone number
    $formattedNumber = substr($originalNumber, 0, 3) . '-' . 
                       substr($originalNumber, 3, 3) . '-' . 
                       substr($originalNumber, 6);
?>

<h5><a href="tel:<?php echo e($originalNumber); ?>"><?php echo e($formattedNumber); ?></a></h5>
  </div>
  </div>
        </div>
        </div>
        </div>
      </div>
    </section>
	
	
	
	<section id="why-coose-section">
	<div class="container">
	  <div class="row">
        <div class="col-lg-7">
<img src="<?php echo e(asset('frontend/images/why-choose-img.png')); ?>"class="img-fluid">
		</div>
		<div class="col-lg-5 align-self-center">
		<p class="head-caption">WHY CHOOSE US</p>
		<h2>Few Reasons to Choose Our Company</h2>
		<p>We offer unparalleled expertise, competitive pricing, and exceptional customer service for all your concrete and asphalt needs. Trust us for reliable, high-quality solutions delivered on time and within budget.</p>
		<ul class="wel-list">
		<li>Experienced professionals ensure top-notch quality.</li>
		<li>Use only high-quality materials.</li>
		<li>Competitive pricing without compromising quality.</li>
		<li>Guaranteed on-time project completion.</li>
		<li>Exceptional customer service and support.</li>
		</ul>
		</div>
		
		</div>
	  </div>
	</section>
	
	
	
	
	
	<section id="testimonial-section">
	<div class="container-fluid">
	  <div class="row">
        <div class="col-lg-6 blue-bg">
		<div class="contact-box-left">
		 		 <p class="head-caption">BOOK APPOINTMENT</p>
		<h2>Asphalt Services Available</h2>
		  <form role="form" action="<?php echo e(route('contact_usPost')); ?>" method="post" id="booking-form">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" value="1" name="type">
                            <div class="controls">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="form-group">
                                            <label>Your Name</label>
                                            <input type="text" required="required" placeholder="First Name"
                                                class="form-control" name="form_name" id="first_name">
                                            <?php $__errorArgs = ['form_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Your Email</label>
                                            <input type="text" required="required" placeholder="Email"
                                                class="form-control" name="form_email" id="form_Email">
                                            <?php $__errorArgs = ['form_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Your Phone</label>
                                            <input type="tel" required="required" placeholder="Phone"
                                                class="form-control" name="form_phone" id="form_Phone">
                                            <?php $__errorArgs = ['form_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Location</label>
                                            <select name="location" id="inputState" class="form-control">
                                                <option selected>Choose...</option>
                                                <option>Option a</option>
                                                <option>Option b</option>
                                                <option>Option c</option>
                                                <option>Option d</option>
                                            </select>
                                            <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Date</label>
                                            <input type="date" class="form-control" id="birthdaytime"
                                                name="birthdaytime" name="booking_date">
                                            <?php $__errorArgs = ['booking_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-12 mt-3">
                                        <input type="submit" value="Submit Request" class="rm-btn w-100">
                                    </div>
                                </div>
                            </div>
                        </form>
		</div>
		</div>
        <div class="col-lg-6">
		<div class="testimonial-box">
		<p class="head-caption">Testimonials</p>
		<h2>CLient feedback</h2>
		<p>Check out what people say about us! Our clients commend our professionalism, reliability, and superior results. Their positive feedback highlights our dedication to delivering top-tier services every time.</p>
		<div id="demo-pranab">
        <div id="owl-testimonial" class="owl-carousel owl-theme">   
        <?php $__empty_1 = true; $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="item">
                                        <div class="testimonial-ctn-box">
                                            <div class="media">
                                                <?php if(isset($testimonial) && !empty($testimonial->image) && File::exists(public_path('storage/TestiImage/' . $testimonial->image))): ?>
                                                    <img
                                                        src="<?php echo e(asset('storage/TestiImage/' . $testimonial->image)); ?>" class="mr-3 pro-img"
                                                        alt="">
                                                <?php else: ?>
                                                    <img src="<?php echo e(asset('frontend/images/pic-img.jpg')); ?>" class="mr-3 pro-img"
                                                        alt="...">
                                                <?php endif; ?>

                                                <div class="media-body align-self-center">
                                                    <h5><?php echo e($testimonial->title); ?></h5>
                                                    <p class="ts-designation mb-0"><?php echo e($testimonial->position); ?></p>
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star checked"></span>
                                                    <span class="fa fa-star"></span>

                                                </div>
                                                <img src="<?php echo e(asset('frontend/images/quote-icon.png')); ?>"class="img-fluid"
                                                    alt="...">
                                            </div>
                                            <p class="tsCtn"><?php echo e($testimonial->text); ?></p>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>  

		  

		  </div>
          </div>
</div>
</div>
</div>
</div>
	</section>
	
	
	

	
	
	
    <section id="client-section">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
        <div id="demo-pranab">
        <div id="owl-client" class="owl-carousel owl-theme">     
         

          <?php $__currentLoopData = $partnerlogos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="item">
          <div class="client-box">
  <img src="<?php echo e(asset('storage/partner_logos/' . $item->image)); ?>"class="img-fluid" alt="...">
          </div>
          </div>
          
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
  
          </div>
          
          </div>
  </div>
  </div>
  </div>
    </section>
	

	
	

    <?php $__env->stopSection(); ?>
<?php echo $__env->make("Frontend.Layout.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\americanasphaltservices\resources\views/Frontend/index.blade.php ENDPATH**/ ?>