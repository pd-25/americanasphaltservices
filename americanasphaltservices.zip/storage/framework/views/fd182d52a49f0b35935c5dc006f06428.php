<?php $__env->startSection('content'); ?>
    <div class="container-xl">
        <div class="app-card alert alert-dismissible shadow-sm mb-4 border-left-decoration" role="alert">
            <div class="inner">
                <div class="app-card app-card-settings shadow-sm p-4">
                    <div class="app-card-body">
                        <?php if(Session::has('msg')): ?>
                            <p class="alert alert-info"><?php echo e(Session::get('msg')); ?></p>
                        <?php endif; ?>
                        <form class="settings-form" action="<?php echo e(route('partner-logo.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            
                            <div id="image-all">
                                <label for="setting-input-3" class="form-label">Image</label>
                                <div class="mb-3 image-field">
                                    <input type="file" name="image[]" class="form-control" required multiple>
                                </div>
                            </div>
                            <div class="mb-3 float-end">
                                <button type="button" class="btn btn-sm btn-success" onclick="addMoreImage()">+ Add more image</button>
                            </div>
                            <div class="mt-5">
                                <button type="submit" class="btn app-btn-primary">Save</button>
                            </div>
                        </form>
                        
                    </div><!--//app-card-body-->
                </div>
            </div><!--//inner-->
        </div><!--//app-card-->
    </div><!--//container-fluid-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function addMoreImage() {
            var html =
                '<div class="mb-3 image-field"><input type="file" name="image[]" class="form-control" required><button type="button" class="btn btn-danger btn-sm remove-image mt-2">Remove</button></div>';
            var container = document.getElementById('image-all');
            container.insertAdjacentHTML('beforeend', html);
        }

        document.addEventListener('click', function(e) {
            if (e.target && e.target.classList.contains('remove-image')) {
                e.target.parentElement.remove();
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\americanasphaltservices\resources\views/admin/partnerlogo/create.blade.php ENDPATH**/ ?>